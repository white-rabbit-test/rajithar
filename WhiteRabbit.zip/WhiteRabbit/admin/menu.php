<div id="top-nav" class="navbar navbar-inverse navbar-static-top" style="background:#c4e3f3;color:white;border-color:white;">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            
        </div>
        <div>
            <h2>Welcome Admin</h2>
            <ul class="nav navbar-nav navbar-right">
                <li><a class="navbar-brand" href="userList.php" > Users</a></li>                    
                <li><a href="fileList.php"><i class="fa fa-user-secret"></i>Files</a></li>	
                
                <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
            </ul>
        </div>
    </div>    
</div>
