<?php 
include('../class/User.php');
$user = new User();
$files = $user->getFiles();
include('include/header.php');
error_reporting(0);
?>
<title>File List</title>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>		
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css" />
<script src="js/users.js"></script>	
<link rel="stylesheet" href="css/style.css">
<?php include('include/container.php');?>
<div class="container contact">			
	<?php include 'menu.php'; ?>
	<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12">   
		<a href="#"><strong><span class="fa fa-dashboard"></span> File List</strong></a>
		<hr>		
		<div class="panel-heading">
			<div class="row">
				<div class="col-md-10">
					<h3 class="panel-title"></h3>
				</div>
				
			</div>
		</div>
		<table  class="table table-bordered table-striped">
			<thead>
				<tr>
					<th>ID</th>
					<th>User</th>					
					<th>File Name</th>	
				</tr>
				<?php 
				
				//echo "<pre>";print_r($files);
				foreach($files as $row){ 
					//echo "<pre>";print_r($row);
					?>
				<tr>
					<td><?php echo $row[0]; ?></td>
					<td><?php echo $row[1]; ?></td>
					<td><?php echo $row[2]; ?></td>
				</tr>
				<?php } ?>

			</thead>
		</table>
	</div>
	</div>	
<?php include('include/footer.php');?>