<?php 
include('../class/User.php');
$user = new User();
$message =  $user->addUser();
include('include/header.php');
?>

<?php include('include/container.php');?>
<div class="container contact">			
	<?php include 'menu.php'; ?>
	<div id="signupbox" class="col-md-12">
		<div class="panel panel-info">
			<div class="panel-heading">
				<div class="panel-title">Create User</div>				
			</div>  
			<div class="panel-body" >
				<form id="signupform" class="form-horizontal" role="form" method="POST" action="">				
					<?php if ($message != '') { ?>
						<div id="login-alert" class="alert alert-danger col-sm-12"><?php echo $message; ?></div>                            
					<?php } ?>	
					<div class="form-group">
						<label for="name" class="col-md-3 control-label">Name*</label>
						<div class="col-md-9">
							<input type="text" class="form-control" name="name" placeholder="Name" value="<?php if(!empty($_POST["name"])) { echo $_POST["name"]; } ?>" required>
						</div>
					</div>									
					<div class="form-group">
						<label for="email" class="col-md-3 control-label">Email Address*</label>
						<div class="col-md-9">
							<input type="email" class="form-control" name="email" placeholder="Email Address" value="<?php if(!empty($_POST["email"])) { echo $_POST["email"]; } ?>" required>
						</div>
					</div>					
					<div class="form-group">
						<label for="password" class="col-md-3 control-label">Password*</label>
						<div class="col-md-9">
							<input type="password" class="form-control" name="passwd" placeholder="Password" required>
						</div>
					</div>								
					<div class="form-group">						                                  
						<div class="col-md-offset-3 col-md-9">
							<button id="btn-signup" type="submit" name="add" value="Create" class="btn btn-info">
								<i class="icon-hand-right"></i> &nbsp Add</button>			
						</div>
					</div>					
									
				</form>
			 </div>
		</div>
	</div>	
</div>
<?php include('include/footer.php');?>