<?php
session_start();
require('include/config.php');
class User extends Dbconfig {	
    protected $hostName;
    protected $userName;
    protected $password;
	protected $dbName;
	private $userTable = 'user';
	private $filesTable = 'files';
	private $fileAccessTable = 'file_access';
	private $dbConnect = false;
    public function __construct(){
        if(!$this->dbConnect){ 		
			$database = new dbConfig();            
            $this -> hostName = $database -> serverName;
            $this -> userName = $database -> userName;
            $this -> password = $database ->password;
			$this -> dbName = $database -> dbName;			
            $conn = new mysqli($this->hostName, $this->userName, $this->password, $this->dbName);
            if($conn->connect_error){
                die("Error failed to connect to MySQL: " . $conn->connect_error);
            } else{
                $this->dbConnect = $conn;
            }
        }
    }
	private function getData($sqlQuery) {
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		if(!$result){
			die('Error in query: '. mysqli_error());
		}
		$data= array();
		while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			$data[]=$row;            
		}
		return $data;
	}
	private function getNumRows($sqlQuery) {
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		if(!$result){
			die('Error in query: '. mysqli_error());
		}
		$numRows = mysqli_num_rows($result);
		return $numRows;
	}	
    public function loginStatus (){
		if(empty($_SESSION["user_id"])) {
			header("Location: login.php");
		}
	}	
	public function uploadFile (){
		if(empty($_SESSION["user_id"])) {
			header("Location: login.php");
		}
		
		if($_FILES["user_file"]["name"]) {
			$target_dir = "uploads/";
			$target_file = $target_dir . basename($_FILES["user_file"]["name"]);
		
			if (move_uploaded_file($_FILES["user_file"]["tmp_name"], $target_file)) {
				$message =  "<bR>The file ". htmlspecialchars( basename( $_FILES["user_file"]["name"])). " has been uploaded.";
			} else {
				$message =  "<bR>Sorry, there was an error uploading your file.";
			}
		
		}

		$insertQuery 	= "INSERT INTO ".$this->filesTable."(created_by, file_name) 
				VALUES ('".$_SESSION["user_id"]."', '".$_FILES["user_file"]["name"]."')";
		$fileSaved 		= mysqli_query($this->dbConnect, $insertQuery);
		$file_id 		= mysql_insert_id();
		$insertQuery 	= "INSERT INTO ".$this->fileAccessTable."(file_id, user_id) 
				VALUES ('".$file_id."', '".$_SESSION["user_id"]."')";
		$Saved 			= mysqli_query($this->dbConnect, $insertQuery);

		if($fileSaved) {
			$message = "File created Successfully!";
			header("Location: account.php");					
		} else {
			$message = "File creation request failed.";
			header("Location: index.php");
		}
			
	}	
	public function login(){		
		$errorMessage = '';
		if(!empty($_POST["login"]) && $_POST["loginId"]!=''&& $_POST["loginPass"]!='') {	
			$loginId = $_POST['loginId'];
			$password = $_POST['loginPass'];
			if(isset($_COOKIE["loginPass"]) && $_COOKIE["loginPass"] == $password) {
				$password = $_COOKIE["loginPass"];
			} else {
				$password = md5($password);
			}	
			$sqlQuery = "SELECT * FROM ".$this->userTable." 
				WHERE email_address='".$loginId."' AND password='".$password."' ";
			$resultSet = mysqli_query($this->dbConnect, $sqlQuery);
			$isValidLogin = mysqli_num_rows($resultSet);	
			if($isValidLogin){				
				$userDetails = mysqli_fetch_assoc($resultSet);
				$_SESSION["user_id"] = $userDetails['user_id'];
				$_SESSION["name"] = $userDetails['name'];
				if($userDetails['role'] == '1'){
					header("location: upload.php"); 
					exit;
				}else{				
					header("location: account.php"); 
				}		
			} else {		
				$errorMessage = "Invalid login!";		 
			}
		} else if(!empty($_POST["loginId"])){
			$errorMessage = "Enter Both user and password!";	
		}
		return $errorMessage; 		
	}
	public function adminLoginStatus (){
		if(empty($_SESSION["adminUserid"])) {
			header("Location: index.php");
		}
	}		
	public function adminLogin(){		
		$errorMessage = '';
		if(!empty($_POST["login"]) && $_POST["email"]!=''&& $_POST["password"]!='') {	
			$email 		= $_POST['email'];
			$password 	= $_POST['password'];
			$sqlQuery 	= "SELECT * FROM ".$this->userTable." 
				WHERE email_address='".$email."' AND password='".md5($password)."' AND role = '1' ";
			$resultSet 	= mysqli_query($this->dbConnect, $sqlQuery);
			$isValidLogin = mysqli_num_rows($resultSet);	
			if($isValidLogin){
				$userDetails = mysqli_fetch_assoc($resultSet);
				$_SESSION["adminUserid"] = $userDetails['user_id'];
				$_SESSION["admin"] = $userDetails['name'];
				header("location: dashboard.php"); 		
			} else {		
				$errorMessage = "Invalid login!";		 
			}
		} else if(!empty($_POST["login"])){
			$errorMessage = "Enter Both user and password!";	
		}
		return $errorMessage; 		
	}
	public function addUser(){		
		$message = '';
		if(!empty($_POST["register"]) && $_POST["email"] !='') {
			$sqlQuery = "SELECT * FROM ".$this->userTable." 
				WHERE email_address='".$_POST["email"]."'";
			$result = mysqli_query($this->dbConnect, $sqlQuery);
			$isUserExist = mysqli_num_rows($result);
			if($isUserExist) {
				$message 		= "User already exist with this email address.";
			} else {			
				$authtoken 		= $this->getAuthtoken($_POST["email"]);
				$insertQuery 	= "INSERT INTO ".$this->userTable."(name, email_address, password, role) 
				VALUES ('".$_POST["name"]."', '".$_POST["email"]."', '".md5($_POST["passwd"])."', '2')";
				$userSaved 		= mysqli_query($this->dbConnect, $insertQuery);
				if($userSaved) {
					$message = "User created Successfully!";
					header("Location: userList.php");					
				} else {
					$message = "Create User request failed.";
				}
			}
		}
		return $message;
	}	
	public function getAuthtoken($email) {
		$code = md5(889966);
		$authtoken = $code."".md5($email);
		return $authtoken;
	}	
	
	public function userDetails () {
		$sqlQuery = "SELECT * FROM ".$this->userTable." 
			WHERE user_id ='".$_SESSION["user_id"]."'";
		$result = mysqli_query($this->dbConnect, $sqlQuery);	
		$userDetails = mysqli_fetch_assoc($result);
		return $userDetails;
	}	
	public function editAccount () {
		$message = '';
		$updatePassword = '';
		if(!empty($_POST["passwd"]) && $_POST["passwd"] != '' && $_POST["passwd"] != $_POST["cpasswd"]) {
			$message = "Confirm passwords do not match.";
		} else if(!empty($_POST["passwd"]) && $_POST["passwd"] != '' && $_POST["passwd"] == $_POST["cpasswd"]) {
			$updatePassword = ", password='".md5($_POST["passwd"])."' ";
		}		
		$updateQuery 		= "UPDATE ".$this->userTable." 
			SET name 		= '".$_POST["name"]."', 
			email_address 	= '".$_POST["email"]."' $updatePassword
			WHERE user_id 	= '".$_SESSION["user_id"]."'";
		$isUpdated 			= mysqli_query($this->dbConnect, $updateQuery);	
		if($isUpdated) {
			$_SESSION["name"] = $_POST['name'];
			$message = "Account details saved.";
		}
		return $message;
	}	
	
	public function savePassword(){
		$message = '';
		if($_POST['password'] != $_POST['cpassword']) {
			$message = "Password does not match the confirm password.";
		} else if($_POST['authtoken']) {
			$sqlQuery = "
				SELECT email, authtoken 
				FROM ".$this->userTable." 
				WHERE authtoken='".$_POST['authtoken']."'";			
			$result = mysqli_query($this->dbConnect, $sqlQuery);
			$numRows = mysqli_num_rows($result);
			if($numRows) {				
				$userDetails = mysqli_fetch_assoc($result);
				$authtoken = $this->getAuthtoken($userDetails['email']);
				if($authtoken == $_POST['authtoken']) {
					$sqlUpdate = "
						UPDATE ".$this->userTable." 
						SET password='".md5($_POST['password'])."'
						WHERE email='".$userDetails['email']."' AND authtoken='".$authtoken."'";	
					$isUpdated = mysqli_query($this->dbConnect, $sqlUpdate);	
					if($isUpdated) {
						$message = "Password saved successfully. Please <a href='login.php'>Login</a> to access account.";
					}
				} else {
					$message = "Invalid password change request.";
				}
			} else {
				$message = "Invalid password change request.";
			}	
		}
		return $message;
	}
	public function getUserList(){		
		$sqlQuery = "SELECT * FROM ".$this->userTable." WHERE user_id !='".$_SESSION['adminUserid']."' ";
		if(!empty($_POST["search"]["value"])){
			$sqlQuery .= '(user_id LIKE "%'.$_POST["search"]["value"].'%" ';
			$sqlQuery .= ' OR name LIKE "%'.$_POST["search"]["value"].'%" ';
			$sqlQuery .= ' OR email_address LIKE "%'.$_POST["search"]["value"].'%" ';					
		}
		if(!empty($_POST["order"])){
			$sqlQuery .= 'ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].' ';
		} else {
			$sqlQuery .= 'ORDER BY user_id DESC ';
		}
		if($_POST["length"] != -1){
			$sqlQuery .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}	
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		
		$sqlQuery1 = "SELECT * FROM ".$this->userTable." WHERE user_id !='".$_SESSION['adminUserid']."' ";
		$result1 = mysqli_query($this->dbConnect, $sqlQuery1);
		$numRows = mysqli_num_rows($result1);
		
		$userData = array();	
		while( $users = mysqli_fetch_assoc($result) ) {		
			$userRows = array();
			
			$userRows[] = $users['user_id'];
			$userRows[] = ucfirst($users['name']);					
			$userRows[] = $users['email_address'];		
			$userRows[] = '<button type="button" name="update" user_id="'.$users["user_id"].'" class="btn btn-warning btn-xs update">Update</button>';
			$userRows[] = '<button type="button" name="delete" user_id="'.$users["user_id"].'" class="btn btn-danger btn-xs delete" >Delete</button>';
			$userData[] = $userRows;
		}
		$output = array(
			"draw"				=>	intval($_POST["draw"]),
			"recordsTotal"  	=>  $numRows,
			"recordsFiltered" 	=> 	$numRows,
			"data"    			=> 	$userData
		);
		echo json_encode($output);
	}
	public function deleteUser(){
		if($_POST["user_id"]) {
			$sqlUpdate = "
				UPDATE ".$this->userTable." SET status = 'deleted'
				WHERE user_id = '".$_POST["user_id"]."'";		
			mysqli_query($this->dbConnect, $sqlUpdate);		
		}
	}
	public function getUser(){
		$sqlQuery = "
			SELECT * FROM ".$this->userTable." 
			WHERE user_id = '".$_POST["user_id"]."'";
		$result = mysqli_query($this->dbConnect, $sqlQuery);	
		$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
		echo json_encode($row);
	}

	public function getFiles(){
		$sqlQuery = " SELECT file_id, file_name, user.name FROM files 
			JOIN user ON user.user_id = files.created_by ";
		$result = mysqli_query($this->dbConnect, $sqlQuery);	
		// foreach( mysqli_fetch_array($result, MYSQLI_ASSOC) as $row ){
		// 	$file_arr = array(
		// 		$file_id => $row->file_id

		// 	);
		// }
		while($row = mysqli_fetch_array($result, MYSQLI_ASSOC) ){
			$file_arr[] = array(
				$row['file_id'],
				$row['name'],
				$row['file_name']
		
			);
		}
	    return $file_arr;
	}	

	public function updateUser() {
		if($_POST['user_id']) {	
			$updateQuery = "UPDATE ".$this->userTable." 
			SET name = '".$_POST["firstname"]."', 
			email_address = '".$_POST["email"]."',
			WHERE user_id ='".$_POST["user_id"]."'";
			$isUpdated = mysqli_query($this->dbConnect, $updateQuery);		
		}	
	}	
		
	public function createAdmin ($email,$password) {
		$password = md5($password);		
		$insertQuery = "INSERT INTO ".$this->userTable."(name, email_address, password, role) 
			VALUES ('Admin','".$email."','". $password."' ,'1')";
		$userSaved 	 = mysqli_query($this->dbConnect, $insertQuery);
		if($userSaved) {
			$message = "<bR>Admin added. --".$email."<----->".$password." !";					
		} else {
			$message =  mysqli_error() ;
		}
		return $message;
	}
	
	public function totalUsers () {	
		
		$sqlQuery = "SELECT * FROM ".$this->userTable." 
		WHERE user_id !='".$_SESSION["adminUserid"]."' ";
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		$numRows = mysqli_num_rows($result);
		return $numRows;
	}
}
?>